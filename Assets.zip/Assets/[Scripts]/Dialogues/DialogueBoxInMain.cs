using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DialogueBoxInMain : DialogueBox
{
    //public void RemoveDialogueInMain()
    //{
    //    base.RemoveDialogue();
    //}
}
