using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DialogueBox : MonoBehaviour
{
    
    public void RemoveDialogue()
    {
        this.gameObject.SetActive(false);
    }
    
}
